git add .
sleep 2
git commit -m "updating"
sleep 2
git push origin main
echo Files pushed to git


